export const enum PopupPageKind {
    Home = 'Home',
    ConnectToSession = 'ConnectToSession',
    ReadSessionDescription = 'ReadSessionDescription',
    CreateSession = 'CreateSession',
    Configure = 'Configure',
    Explore = 'Explore'
}