export default class Token  {

    public token : string;
    
    constructor(token : string) {
        this.token = token;
    }

}

