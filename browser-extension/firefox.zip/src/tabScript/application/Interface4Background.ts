export default interface Interface4Background {

  explorationStarted():void;

  explorationStopped():void;

  reload():void;

}