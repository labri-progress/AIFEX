export class Step {
    public expression: string;

    constructor(expression: string) {
        this.expression = expression;
    }
}
