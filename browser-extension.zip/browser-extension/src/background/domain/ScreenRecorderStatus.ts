enum ScreenRecorderStatus {
    stopped,
    started,
    paused
}