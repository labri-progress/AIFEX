export default class Evaluator {
    public scenario: string;

    constructor(scenario: string) {
        this.scenario = scenario;
    }
}