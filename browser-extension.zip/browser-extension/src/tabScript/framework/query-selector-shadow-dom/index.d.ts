declare module 'query-selector-shadow-dom' {
    export function querySelectorAllDeep(selector : string, context? : Node) : Element[]; 
}

