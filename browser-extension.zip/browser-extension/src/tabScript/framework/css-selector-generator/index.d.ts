declare module 'css-selector-generator' {
    export default function getCssSelector(target : EventTarget, option : {selectors:string[]}) : string; 
}

