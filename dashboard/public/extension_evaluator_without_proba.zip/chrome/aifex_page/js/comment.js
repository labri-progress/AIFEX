document.getElementById("submitComment").addEventListener("click", submitComment);
document.getElementById("clearComment").addEventListener("click", clearComment);
document.getElementById("displayCommentsCheckbox").addEventListener("change", updateDisplayUserView);

function submitComment(e) {
    e.preventDefault();
    
    const type = document.getElementById('commentType').value;
    const value = document.getElementById('commentDescription').value;
    sendMessage({
        kind: "pushComment",
        type,
        value
    })
    .then(response => {
        if (response !== undefined) {
            const screenshot = document.getElementById('commentScreenshot').value;
            if (screenshot) {
                sendMessage({
                    kind: "takeScreenshot"
                });
            }
            document.getElementById("commentSuccessul").style.display = 'block'
            document.getElementById('commentDescription').value = "";
        } else {
            console.error('Error sendMessage')
        }
    });

}

function clearComment(e) {
    e.preventDefault();
    document.getElementById('commentDescription').value = "";
}

function updateDisplayUserView(e) {
    e.preventDefault();
    const isTabScriptDisplayingUserView = e.target.checked
    sendMessage({
        kind: "setIsTabScriptDiplayingUserView",
        isTabScriptDisplayingUserView
    });
}
